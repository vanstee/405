Description:
This is a solution to homework project 1 with both basic requirements 
and advanced extension implemented.

Name: Patrick Van Stee

Date: Javuary 25, 2011

Instructions:
$ make clean && make
$ ./imgview or ./imgview image.jpg
Press r to read and display a new image form a file
Press w to write the currently displayed image to a file
Press q or ESC to quit the program